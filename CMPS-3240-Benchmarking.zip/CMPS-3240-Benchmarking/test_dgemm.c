#include <stdio.h>
#include <stdlib.h>

void dgemm (int n, double* A, double* B, double* C) {
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
         double cij = C[i+j*n]; /* cij = C[i][j] */           
         for( int k = 0; k < n; k++ ) {
             cij += A[i+k*n] * B[k+j*n]; /* cij += A[i][k]*B[k][j] */
         }
         C[i+j*n] = cij; /* C[i][j] = cij */
      }
   }
}

//  The benchmark
int main( void ) {
  const int N = 1024; // The benchmark runs on a fixed size of work
  printf( "Running DGEMM operation of size %d x 1\n", N );

  //  Create three N x 1 matrixes on the heap using malloc. There are 
  //  generally two reasons why we do not want to do this statically i.e. int 
  //  X[N]. One, with the benchmark program we're making we may exceed the 
  //  allowable size of a static array (yep, this is possible given we are 
  //  taxing the system). Two, if you wanted to, you could dynamically adjust 
  //  the workload via the command line (though this is not how it is currently
  //  set up).                                     
  double *X = (double *) malloc( N * N *  sizeof(double) );      // First vector
  double *Y = (double *) malloc( N * N* sizeof(double) );      // Second vector
  double *C = (double *) malloc (N *N * sizeof(double) );      // result vector 
   // Carry out the operation
  dgemm( N, X, C, Y);

   // Free up the memory
   free( X );
   free( Y );
   free( C );
   return 0;
}
